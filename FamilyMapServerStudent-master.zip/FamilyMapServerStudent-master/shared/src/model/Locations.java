package model;

public class Locations {

    Location [] data;

    public Locations(Location[] data) {
        this.data = data;
    }

    public Location[] getData() {
        return data;
    }

    public void setData(Location[] data) {
        this.data = data;
    }
}
