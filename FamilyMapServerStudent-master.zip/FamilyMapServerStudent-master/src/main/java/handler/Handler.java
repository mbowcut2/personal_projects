package handler;

public abstract class Handler {


    private String encode(String json) {
        return null;
    }

    private String decode(String json) {
        return null;
    }

}
